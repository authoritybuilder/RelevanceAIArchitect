# Agent Architect

A workspace for designing, scoping, and shipping AI agents on Relevance AI. Inspired by Wei Li's methodology, built as a model I can refine over time to help me think toward L4 builds.

Going through the bootcamp, I realised Relevance has put together so much genuinely good content that I wanted a way to use ALL of it as my portfolio grows, not just the bits I happen to remember in the moment. So I built one place that holds it.

> Built during the Relevance AI AI Ops Bootcamp Cohort 2. Free, MIT-licensed.

🚀 **Live:** https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/

---

## What it does

Twenty-four panels that walk you from "I think there might be an agent here" to "here's the prompt, the operating card, the implementation plan, and the memo I send to my manager."

- **Program** — Welcome, Tracker (kanban), Cohesion (portfolio map), Discover (find workflows in your chat history), Autonomy Tracker
- **Design** — Wizard (guided scoping), Map My AI (mind map of your build), Roadmap (autonomy ladder L1→L4), Prompts, Guardrails, Cost estimator, Programmatic GTM, Business Context
- **Ship** — Implementation (rollout plan, comms templates, readiness checks), Operating Card, Self-Critique
- **Iterate** — Diagnose (5-layer failure model), Ask AI (11 calibrated scan prompts), Stuck

Plus Settings, How To Use, Gantt and Calendar views. Saves to local storage. Nothing leaves your device.

---

## Deploy your own copy to GitHub Pages (3 minutes, no build needed)

This version has no build step. Just three files. Push and go.

1. **Create a GitHub repo** (any name, public)
2. **Upload these three files** to the repo root:
   - `index.html`
   - `agent-architect.js`
   - `404.html`
3. **Enable GitHub Pages**:
   - Repo → **Settings** → **Pages**
   - Under **Build and deployment** → **Source**, select **Deploy from a branch**
   - Branch: **main** (or whatever your default is) / **(root)**
   - Click **Save**
4. **Wait ~60 seconds**, then visit `https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/`

That's it. No Vite, no Actions, no npm. The page loads React from a CDN, runs the pre-transformed JS, and renders the tool.

---

## Run it locally

Any static file server works. The simplest:

```bash
# In the repo folder:
python3 -m http.server 8080
# OR
npx serve .
```

Then open `http://localhost:8080`.

---

## Use it inside Claude (alternative)

If you'd rather have it inside a Claude chat (so you can ask Claude questions about your build alongside it):

1. Open [claude.ai](https://claude.ai/new) and start a new chat
2. The original artefact source is too large to paste; instead, share the live URL or share `agent-architect.js` and ask Claude to wrap it in HTML

The live deploy is the path of least friction.

---

## How it works (for the curious)

- **`index.html`** — the entry point. Loads React 18 from unpkg CDN, sets up a localStorage shim so persistence works, and loads the application JS.
- **`agent-architect.js`** — the application, pre-transformed from JSX to plain browser-runnable JavaScript. About 933 KB. Single file because the original was a single artefact for Claude.ai.
- **`404.html`** — a copy of `index.html`. GitHub Pages serves this for any path that doesn't match a file. Means any URL on your site lands on the app.

No build step. No bundler. No dependencies to install. The tradeoff: the JS file isn't tree-shaken or minified, so it's larger than a built version. For a tool this size, the simplicity wins.

---

## What this isn't

- **Not the platform itself.** Builds the agents on [Relevance AI](https://relevanceai.com); this is the planning workspace.
- **A personal project**, built independently to help me work through the framework.
- **Not a replacement for the bootcamp.** Encodes the thinking I'm learning; doesn't replace doing the work.

---

## License

MIT. Use it, fork it, modify it, ship it. Attribution appreciated but not required.

---

## Credits

Inspired by Wei Li's methodology. Built during the Relevance AI AI Ops Bootcamp, Cohort 2. The framework throughout (autonomy levels L1-L4, the four core agent parts, the questionnaire structure, the failure-layer model) comes from the bootcamp content. The implementation is mine.

Thanks to the bootcamp instructors and the cohort for the conversations that shaped what was worth building.
